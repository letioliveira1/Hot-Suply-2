<?php

namespace App\Controllers;

class Pagamento extends BaseController
{
	private $uModel;

	public function __construct()
	{
		// Criamos uma instância do model
		$this->uModel = new \App\Models\PagamentoModel();
	}

	public function index()
	{
		// Estruturamos o array que envia as informações para view
		// Recuperando todos os registros da tabela usuarios
		// Organizados já na estrutura de paginação nativa do CodeIgniter 4
		$dados = [
			'pagamentos'  => $this->uModel->paginate(100),
			'paginacao' => $this->uModel->pager, // Estrutura de paginação (links)
			'sessao'    => $this->session
		];

		// Carregamos a view
		return view('indexPagamento', $dados);
	}

	public function novo()
	{
		// Estruturamos o array que envia as informações para view
		// Recuperando as informações da entidade Usuario
		$dados = [
			'sessao'   => $this->session,
			'sucesso' => ($this->request->getMethod() === 'post') ? true : false,
			'erros'   => [],
			'pagamento' => new \App\Entities\Pagamento()
		];

		// Verificamos se o formulário foi submetido
		if ($this->request->getPost()) {
			// Criamos uma nova entidade Usuario que receberá os dados enviados
			// através do formulário para que sejam devidamente formatados e estruturados
			// para então serem salvos no banco de dados
			$pagamento   = new \App\Entities\Pagamento();

			// Recuperamos os dados enviados pelo formulário
			$dtPagamento = $this->request->getPost();

			// Salvamos os registros na tabela 'usuarios' utilizando os recursos da entidade
			// Usuario para estruturar e formatar os dados para então salvar no banco de dados
			// e em caso de erroretornamos os mesmos para a variável 'dados' para serem exibidos
			// na view
			if ($this->uModel->save($pagamento->fill($dtPagamento)) === false) {
				$dados['sucesso'] = false;
				$dados['erros']   = $this->uModel->errors();
				$dados['pagamento'] = $pagamento;
			}
		}

		// Carregamos a view
		return view('novoPagamento', $dados);
	}

	public function editar($idPagamento = null)
	{
		// Recuperamos as informações do usuário
		$pagamento = $this->uModel->find($idPagamento);

		// Verificamos se foi encontrado um usuário com o ID informado
		// Se não retornou nenhum usuário, então redirecionamos para a página principal
		if (is_null($pagamento)) {
			$this->session->setFlashdata('msgWarning', 'Nenhum pagamento encontrado para edição.');
			return redirect()->to(base_url());
		}

		// Estruturamos o array que envia as informações para view
		$dados = [
			'sessao'   => $this->session,
			'sucesso' => ($this->request->getMethod() === 'post') ? true : false,
			'erros'   => [],
			'pagamento' => $pagamento
		];

		// Verificamos se o formulário foi submetido
		if ($this->request->getPost()) {
			// Recuperamos os dados enviados pelo formulário
			$dtPagamento = $this->request->getPost();

			// Salvamos os registros na tabela 'usuarios' e em caso de erro
			// retornamos os mesmos para a variável 'dados' para serem exibidos
			// na view
			if ($this->uModel->save($pagamento->fill($dtPagamento)) === false) {
				$dados['sucesso'] = false;
				$dados['erros']   = $this->uModel->errors();
			}
		}

		// Carregamos a view
		return view('editarPagamento', $dados);
	}

	public function excluir($idPagamento = null)
	{
		// Recuperamos as informações do usuário
		$pagamento = $this->uModel->find($idPagamento);
		// Definimos mensagem padrão para o caso de erro na exclusão do usuário
		$this->session->setFlashdata('msgWarning', 'Não foi possível excluir o pagamento.');

		// Verificamos se foi encontrado um usuário com o ID informado
		// Se não retornou nenhum usuário, então redirecionamos para a página principal
		// Com uma mensagem a ser exibida
		if (is_null($pagamento)) {
			$this->session->setFlashdata('msgWarning', 'Nenhum pagamento encontrado para excluir.');
			return redirect()->to(base_url());
		}

		// Executamos a exclusão do usuário
		// E se executar com sucesso, definimos a mensagem de sucesso
		if ($this->uModel->delete(['id' => $idPagamento])) {
			$this->session->setFlashdata('msgWarning', 'Pagamento excluído com sucesso.');
		}

		// Redirecionamos para página principal
		return redirect()->to(base_url('pagamento'));
	}
}
