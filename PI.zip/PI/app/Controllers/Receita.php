<?php

namespace App\Controllers;

use CodeIgniter\Files\File;

class Receita extends BaseController
{
	private $uModel;

	protected $helpers = ['form'];

	public function __construct()
	{
		// Criamos uma instância do model
		$this->uModel = new \App\Models\ReceitaModel();
	}

	public function index()
	{
		// Estruturamos o array que envia as informações para view
		// Recuperando todos os registros da tabela usuarios
		// Organizados já na estrutura de paginação nativa do CodeIgniter 4
		$dados = [
			'receitas'  => $this->uModel->paginate(100),
			'paginacao' => $this->uModel->pager, // Estrutura de paginação (links)
			'sessao'    => $this->session
		];

		// Carregamos a view
		return view('indexReceita', $dados);
	}


	public function novo()
	{
		// Estruturamos o array que envia as informações para view
		// Recuperando as informações da entidade Usuario
		$dados = [
			'sessao'   => $this->session,
			'sucesso' => ($this->request->getMethod() === 'post') ? true : false,
			'erros'   => [],
			'receita' => new \App\Entities\Receita()
		];

		// Verificamos se o formulário foi submetido
		if ($this->request->getPost()) {
			// Criamos uma nova entidade Usuario que receberá os dados enviados
			// através do formulário para que sejam devidamente formatados e estruturados
			// para então serem salvos no banco de dados
			$receita   = new \App\Entities\Receita();

			// Recuperamos os dados enviados pelo formulário
			$dtReceita = $this->request->getPost();

			//img

			$img = $this->request->getFile('Imagem');

			if ($imagefile = $this->request->getFiles()) {
				
					if ($img->isValid() && ! $img->hasMoved()) {
						$newName = $img->getName();
						$img->move(ROOTPATH . '/public/img/', $newName);

						$dtReceita['Imagem'] = $newName;
					}
				
			}

			// Salvamos os registros na tabela 'usuarios' utilizando os recursos da entidade
			// Usuario para estruturar e formatar os dados para então salvar no banco de dados
			// e em caso de erroretornamos os mesmos para a variável 'dados' para serem exibidos
			// na view
			if ($this->uModel->save($receita->fill($dtReceita)) === false) {
				$dados['sucesso'] = false;
				$dados['erros']   = $this->uModel->errors();
				$dados['receita'] = $receita;
			}
		}

		// Carregamos a view
		return view('novoReceita', $dados);
	}


    public function editar($idReceita = null)
	{
		// Recuperamos as informações do usuário
		$receita = $this->uModel->find($idReceita);

		// Verificamos se foi encontrado um usuário com o ID informado
		// Se não retornou nenhum usuário, então redirecionamos para a página principal
		if (is_null($receita)) {
			$this->session->setFlashdata('msgWarning', 'Nenhuma receita encontrado para edição.');
			return redirect()->to(base_url());
		}

		// Estruturamos o array que envia as informações para view
		$dados = [
			'sessao'   => $this->session,
			'sucesso' => ($this->request->getMethod() === 'post') ? true : false,
			'erros'   => [],
			'receita' => $receita
		];

		// Verificamos se o formulário foi submetido
		if ($this->request->getPost()) {
			// Recuperamos os dados enviados pelo formulário
			$dtReceita = $this->request->getPost();

			// Salvamos os registros na tabela 'usuarios' e em caso de erro
			// retornamos os mesmos para a variável 'dados' para serem exibidos
			// na view
			if ($this->uModel->save($receita->fill($dtReceita)) === false) {
				$dados['sucesso'] = false;
				$dados['erros']   = $this->uModel->errors();
				return redirect()->to(base_url('/receita'));

			}
		}

		// Carregamos a view
		return view('editarReceita', $dados);
		
	}

	public function excluir($idReceita = null)
	{
		// Recuperamos as informações do usuário
		$receita = $this->uModel->find($idReceita);
		// Definimos mensagem padrão para o caso de erro na exclusão do usuário
		$this->session->setFlashdata('msgWarning', 'Não foi possível excluir a receita.');

		// Verificamos se foi encontrado um usuário com o ID informado
		// Se não retornou nenhum usuário, então redirecionamos para a página principal
		// Com uma mensagem a ser exibida
		if (is_null($receita)) {
			$this->session->setFlashdata('msgWarning', 'Nenhuma receita encontrado para excluir.');
			return redirect()->to(base_url());
		}

		// Executamos a exclusão do usuário
		// E se executar com sucesso, definimos a mensagem de sucesso
		if ($this->uModel->delete(['idReceita' => $idReceita])) {
			$this->session->setFlashdata('msgWarning', 'Receita excluída com sucesso.');
		}

		// Redirecionamos para página principal
		return redirect()->to(base_url('/receita'));
	}

	public function indexPublico()
	{
		// Estruturamos o array que envia as informações para view
		// Recuperando todos os registros da tabela usuarios
		// Organizados já na estrutura de paginação nativa do CodeIgniter 4
		$dados = [
			'receitas'  => $this->uModel->paginate(100),
			'paginacao' => $this->uModel->pager, // Estrutura de paginação (links)
			'sessao'    => $this->session
		];

		// Carregamos a view
		return view('receitas', $dados);
	}


}

