<?php

namespace App\Controllers;

class Cliente extends BaseController
{
	private $uModel;

	public function __construct()
	{
		// Criamos uma instância do model
		$this->uModel = new \App\Models\ClienteModel();
	}

	public function login()
 	{
		$session = session();
 		//$uModel = new ClienteModel();
 		$username = $this->request->getVar('username');
 		$password = $this->request->getVar('password');
 		$cliente = $this->uModel->where('username', $username)->first();
		if ($cliente && ($password === $cliente->password)) 
		{
 		$session->set('cliente_id', $cliente->id);
 		return redirect()->to('/');
 		}
		else {
 		$session->setFlashdata('error', 'Username ou senha incorretos.');
 		return redirect()->back();
 		}
 	}

 	public function logout()
 	{
 		$session = session();
 		$session->destroy();
 		return redirect()->to('/login');
 
	}

	public function index()
	{
		// Estruturamos o array que envia as informações para view
		// Recuperando todos os registros da tabela usuarios
		// Organizados já na estrutura de paginação nativa do CodeIgniter 4
		
		// Carregamos a view
		return view('login');

	}

	public function novo()
	{
		// Estruturamos o array que envia as informações para view
		// Recuperando as informações da entidade Usuario
		$dados = [
			'sessao'   => $this->session,
			'sucesso' => ($this->request->getMethod() === 'post') ? true : false,
			'erros'   => [],
			'cliente' => new \App\Entities\Cliente()
		];

		// Verificamos se o formulário foi submetido
		if ($this->request->getPost()) {
			// Criamos uma nova entidade Usuario que receberá os dados enviados
			// através do formulário para que sejam devidamente formatados e estruturados
			// para então serem salvos no banco de dados
			$cliente   = new \App\Entities\Cliente();

			// Recuperamos os dados enviados pelo formulário
			$dtCliente = $this->request->getPost();

			// Salvamos os registros na tabela 'usuarios' utilizando os recursos da entidade
			// Usuario para estruturar e formatar os dados para então salvar no banco de dados
			// e em caso de erroretornamos os mesmos para a variável 'dados' para serem exibidos
			// na view
			if ($this->uModel->save($cliente->fill($dtCliente)) === false) {
				$dados['sucesso'] = false;
				$dados['erros']   = $this->uModel->errors();
				$dados['cliente'] = $cliente;
			}
		}

		// Carregamos a view
		return view('novoCliente', $dados);
	}

	public function editar($idCliente = null)
	{
		// Recuperamos as informações do usuário
		$cliente = $this->uModel->find($idCliente);

		// Verificamos se foi encontrado um usuário com o ID informado
		// Se não retornou nenhum usuário, então redirecionamos para a página principal
		if (is_null($cliente)) {
			$this->session->setFlashdata('msgWarning', 'Nenhum cliente encontrado para edição.');
			return redirect()->to(base_url());
		}

		// Estruturamos o array que envia as informações para view
		$dados = [
			'sessao'   => $this->session,
			'sucesso' => ($this->request->getMethod() === 'post') ? true : false,
			'erros'   => [],
			'cliente' => $cliente
		];

		// Verificamos se o formulário foi submetido
		if ($this->request->getPost()) {
			// Recuperamos os dados enviados pelo formulário
			$dtCliente = $this->request->getPost();

			// Salvamos os registros na tabela 'usuarios' e em caso de erro
			// retornamos os mesmos para a variável 'dados' para serem exibidos
			// na view
			if ($this->uModel->save($cliente->fill($dtCliente)) === false) {
				$dados['sucesso'] = false;
				$dados['erros']   = $this->uModel->errors();
			}
		}

		// Carregamos a view
		return view('editarCliente', $dados);
	}

	public function excluir($idCliente = null)
	{
		// Recuperamos as informações do usuário
		$cliente = $this->uModel->find($idCliente);
		// Definimos mensagem padrão para o caso de erro na exclusão do usuário
		$this->session->setFlashdata('msgWarning', 'Não foi possível excluir o cliente.');

		// Verificamos se foi encontrado um usuário com o ID informado
		// Se não retornou nenhum usuário, então redirecionamos para a página principal
		// Com uma mensagem a ser exibida
		if (is_null($cliente)) {
			$this->session->setFlashdata('msgWarning', 'Nenhum cliente encontrado para excluir.');
			return redirect()->to(base_url());
		}

		// Executamos a exclusão do usuário
		// E se executar com sucesso, definimos a mensagem de sucesso
		if ($this->uModel->delete(['id' => $idCliente])) {
			$this->session->setFlashdata('msgWarning', 'Cliente excluído com sucesso.');
		}

		// Redirecionamos para página principal
		return redirect()->to(base_url('cliente'));
	}
}
