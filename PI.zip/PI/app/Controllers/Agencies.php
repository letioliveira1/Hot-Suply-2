<?php namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\AgencyModel;

class Agencies extends BaseController
{
public function index(): string
{    
  $model = new AgencyModel(); 
  $data['agencies'] = $model->orderBy('id', 'DESC')->findAll();    
  return view('agencies', $data);
}
}