<?php

namespace App\Controllers;

class Categoria extends BaseController
{
	private $uModel;

	public function __construct()
	{
		// Criamos uma instância do model
		$this->uModel = new \App\Models\CategoriaModel();
	}

	public function index()
	{
		// Estruturamos o array que envia as informações para view
		// Recuperando todos os registros da tabela usuarios
		// Organizados já na estrutura de paginação nativa do CodeIgniter 4
		$dados = [
			'categoria'  => $this->uModel->paginate(100),
			'paginacao' => $this->uModel->pager, // Estrutura de paginação (links)
			'sessao'    => $this->session
		];

		// Carregamos a view
		return view('indexCategoria', $dados);
	}

	public function novo()
	{
		// Estruturamos o array que envia as informações para view
		// Recuperando as informações da entidade Usuario
		$dados = [
			'sessao'   => $this->session,
			'sucesso' => ($this->request->getMethod() === 'post') ? true : false,
			'erros'   => [],
			'categoria' => new \App\Entities\Categoria()
		];

		// Verificamos se o formulário foi submetido
		if ($this->request->getPost()) {
			// Criamos uma nova entidade Usuario que receberá os dados enviados
			// através do formulário para que sejam devidamente formatados e estruturados
			// para então serem salvos no banco de dados
			$categoria   = new \App\Entities\Categoria();

			// Recuperamos os dados enviados pelo formulário
			$dtCategoria = $this->request->getPost();

			// Salvamos os registros na tabela 'usuarios' utilizando os recursos da entidade
			// Usuario para estruturar e formatar os dados para então salvar no banco de dados
			// e em caso de erroretornamos os mesmos para a variável 'dados' para serem exibidos
			// na view
			if ($this->uModel->save($categoria->fill($dtCategoria)) === false) {
				$dados['sucesso'] = false;
				$dados['erros']   = $this->uModel->errors();
				$dados['categoria'] = $categoria;
			}
		}

		// Carregamos a view
		return view('novoCategoria', $dados);
	}

	public function editar($idCategoria = null)
	{
		// Recuperamos as informações do usuário
		$categoria = $this->uModel->find($idCategoria);

		// Verificamos se foi encontrado um usuário com o ID informado
		// Se não retornou nenhum usuário, então redirecionamos para a página principal
		if (is_null($categoria)) {
			$this->session->setFlashdata('msgWarning', 'Nenhuma categoria encontrada para edição.');
			return redirect()->to(base_url());
		}

		// Estruturamos o array que envia as informações para view
		$dados = [
			'sessao'   => $this->session,
			'sucesso' => ($this->request->getMethod() === 'post') ? true : false,
			'erros'   => [],
			'categoria' => $categoria
		];

		// Verificamos se o formulário foi submetido
		if ($this->request->getPost()) {
			// Recuperamos os dados enviados pelo formulário
			$dtCategoria = $this->request->getPost();

			// Salvamos os registros na tabela 'usuarios' e em caso de erro
			// retornamos os mesmos para a variável 'dados' para serem exibidos
			// na view
			if ($this->uModel->save($categoria->fill($dtCategoria)) === false) {
				$dados['sucesso'] = false;
				$dados['erros']   = $this->uModel->errors();
			}
		}

		// Carregamos a view
		return view('editarCategoria', $dados);
	}

	public function excluir($idCategoria = null)
	{
		// Recuperamos as informações do usuário
		$categoria = $this->uModel->find($idCategoria);
		// Definimos mensagem padrão para o caso de erro na exclusão do usuário
		$this->session->setFlashdata('msgWarning', 'Não foi possível excluir a categoria.');

		// Verificamos se foi encontrado um usuário com o ID informado
		// Se não retornou nenhum usuário, então redirecionamos para a página principal
		// Com uma mensagem a ser exibida
		if (is_null($categoria)) {
			$this->session->setFlashdata('msgWarning', 'Nenhuma categoria encontrado para excluir.');
			return redirect()->to(base_url());
		}

		// Executamos a exclusão do usuário
		// E se executar com sucesso, definimos a mensagem de sucesso
		if ($this->uModel->delete(['id' => $idCategoria])) {
			$this->session->setFlashdata('msgWarning', 'Categoria excluída com sucesso.');
		}

		// Redirecionamos para página principal
		return redirect()->to(base_url('categoria'));
	}
}
