<?php

namespace App\Controllers;

class Usuario extends BaseController
{
	private $uModel;

	public function __construct()
	{
		// Criamos uma instância do model
		$this->uModel = new \App\Models\UsuarioModel();
	}

	public function index()
	{
		// Estruturamos o array que envia as informações para view
		// Recuperando todos os registros da tabela usuarios
		// Organizados já na estrutura de paginação nativa do CodeIgniter 4
		$dados = [
			'usuarios'  => $this->uModel->paginate(100),
			'paginacao' => $this->uModel->pager, // Estrutura de paginação (links)
			'sessao'    => $this->session
		];

		// Carregamos a view
		return view('index', $dados);
	}

	public function novo()
	{
		// Estruturamos o array que envia as informações para view
		// Recuperando as informações da entidade Usuario
		$dados = [
			'sessao'   => $this->session,
			'sucesso' => ($this->request->getMethod() === 'post') ? true : false,
			'erros'   => [],
			'usuario' => new \App\Entities\Usuario()
		];

		// Verificamos se o formulário foi submetido
		if ($this->request->getPost()) {
			// Criamos uma nova entidade Usuario que receberá os dados enviados
			// através do formulário para que sejam devidamente formatados e estruturados
			// para então serem salvos no banco de dados
			$usuario   = new \App\Entities\Usuario();

			// Recuperamos os dados enviados pelo formulário
			$dtUsuario = $this->request->getPost();

			// Salvamos os registros na tabela 'usuarios' utilizando os recursos da entidade
			// Usuario para estruturar e formatar os dados para então salvar no banco de dados
			// e em caso de erroretornamos os mesmos para a variável 'dados' para serem exibidos
			// na view
			if ($this->uModel->save($usuario->fill($dtUsuario)) === false) {
				$dados['sucesso'] = false;
				$dados['erros']   = $this->uModel->errors();
				$dados['usuario'] = $usuario;
			}
		}

		// Carregamos a view
		return view('novo', $dados);
	}


}
