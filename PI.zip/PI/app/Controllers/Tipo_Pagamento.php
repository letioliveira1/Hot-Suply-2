<?php

namespace App\Controllers;

class Tipo_Pagamento extends BaseController
{
	private $uModel;

	public function __construct()
	{
		// Criamos uma instância do model
		$this->uModel = new \App\Models\Tipo_PagamentoModel();
	}

	public function index()
	{
		// Estruturamos o array que envia as informações para view
		// Recuperando todos os registros da tabela usuarios
		// Organizados já na estrutura de paginação nativa do CodeIgniter 4
		$dados = [
			'tipo_pagamento'  => $this->uModel->paginate(100),
			'paginacao' => $this->uModel->pager, // Estrutura de paginação (links)
			'sessao'    => $this->session
		];

		// Carregamos a view
		return view('indexTipo_Pagamento', $dados);
	}

	public function novo()
	{
		// Estruturamos o array que envia as informações para view
		// Recuperando as informações da entidade Usuario
		$dados = [
			'sessao'   => $this->session,
			'sucesso' => ($this->request->getMethod() === 'post') ? true : false,
			'erros'   => [],
			'tipo_pagamento' => new \App\Entities\Tipo_Pagamento()
		];

		// Verificamos se o formulário foi submetido
		if ($this->request->getPost()) {
			// Criamos uma nova entidade Usuario que receberá os dados enviados
			// através do formulário para que sejam devidamente formatados e estruturados
			// para então serem salvos no banco de dados
			$tipo_pagamento   = new \App\Entities\Tipo_Pagamento();

			// Recuperamos os dados enviados pelo formulário
			$dtTipoPagamento = $this->request->getPost();

			// Salvamos os registros na tabela 'usuarios' utilizando os recursos da entidade
			// Usuario para estruturar e formatar os dados para então salvar no banco de dados
			// e em caso de erroretornamos os mesmos para a variável 'dados' para serem exibidos
			// na view
			if ($this->uModel->save($tipo_pagamento->fill($dtTipoPagamento)) === false) {
				$dados['sucesso'] = false;
				$dados['erros']   = $this->uModel->errors();
				$dados['tipo_pagamento'] = $tipo_pagamento;
			}
		}

		// Carregamos a view
		return view('novoTipo_Pagamento', $dados);
	}

	public function editar($idTipoPagamento = null)
	{
		// Recuperamos as informações do usuário
		$tipo_pagamento = $this->uModel->find($idTipoPagamento);

		// Verificamos se foi encontrado um usuário com o ID informado
		// Se não retornou nenhum usuário, então redirecionamos para a página principal
		if (is_null($tipo_pagamento)) {
			$this->session->setFlashdata('msgWarning', 'Nenhum tipo pagamento encontrado para edição.');
			return redirect()->to(base_url());
		}

		// Estruturamos o array que envia as informações para view
		$dados = [
			'sessao'   => $this->session,
			'sucesso' => ($this->request->getMethod() === 'post') ? true : false,
			'erros'   => [],
			'tipo_pagamento' => $tipo_pagamento
		];

		// Verificamos se o formulário foi submetido
		if ($this->request->getPost()) {
			// Recuperamos os dados enviados pelo formulário
			$dtTipoPagamento = $this->request->getPost();

			// Salvamos os registros na tabela 'usuarios' e em caso de erro
			// retornamos os mesmos para a variável 'dados' para serem exibidos
			// na view
			if ($this->uModel->save($tipo_pagamento->fill($dtTipoPagamento)) === false) {
				$dados['sucesso'] = false;
				$dados['erros']   = $this->uModel->errors();
			}
		}

		// Carregamos a view
		return view('editarTipo_Pagamento', $dados);
	}

	public function excluir($idTipoPagamento = null)
	{
		// Recuperamos as informações do usuário
		$tipo_pagamento = $this->uModel->find($idTipoPagamento);
		// Definimos mensagem padrão para o caso de erro na exclusão do usuário
		$this->session->setFlashdata('msgWarning', 'Não foi possível excluir o tipo pagamento.');

		// Verificamos se foi encontrado um usuário com o ID informado
		// Se não retornou nenhum usuário, então redirecionamos para a página principal
		// Com uma mensagem a ser exibida
		if (is_null($tipo_pagamento)) {
			$this->session->setFlashdata('msgWarning', 'Nenhum tipo pagamento encontrado para excluir.');
			return redirect()->to(base_url());
		}

		// Executamos a exclusão do usuário
		// E se executar com sucesso, definimos a mensagem de sucesso
		if ($this->uModel->delete(['id' => $idTipoPagamento])) {
			$this->session->setFlashdata('msgWarning', 'Tipo pagamento excluído com sucesso.');
		}

		// Redirecionamos para página principal
		return redirect()->to(base_url('Tipo_Pagamento'));
	}
}
