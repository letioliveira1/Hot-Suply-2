<?php

namespace App\Entities;

use CodeIgniter\Entity;
use CodeIgniter\I18n\Time;

class Cliente extends Entity
{
    // Definimos os atributos de acordo com as colunas existentes na tabela usuarios
    protected $attributes = [
        'idCliente'             => null,
        'nome'        => null,
        'cpf'         => null,
        'endereco'            => null,
        'data_nasc'    => null,
        'telefone' => null,
        'email'        => null,
        'username'  => null,
        'password' => null,
    ];

    // Método responsável por executar a formatação do campo data de nascimento
    // Antes de inserir no banco de dados, mantendo assim o padrão "Y-m-d"
    public function setdata_nasc(string $dateString)
    {
        $date = \DateTime::createFromFormat('d/m/Y', $dateString);
        $this->attributes['data_nasc'] = $date->format('Y-m-d');
        return $this;
    }

    // Método responsável por formatar a data no padrão "d/m/Y" antes de retornar os dados
    public function getdata_nasc(string $format = 'd/m/Y')
    {
        if(is_null($this->attributes['data_nasc'])) {
            return null;
        }

        $this->attributes['data_nasc'] = date($format, strtotime($this->attributes['data_nasc']));

        return $this->attributes['data_nasc'];
    }
}
