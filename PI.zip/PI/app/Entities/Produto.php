<?php

namespace App\Entities;

use CodeIgniter\Entity;
use CodeIgniter\I18n\Time;

class Produto extends Entity
{
    // Definimos os atributos de acordo com as colunas existentes na tabela usuarios
    protected $attributes = [
        'idProduto'             => null,
        'preco'        => null,
        'descricao'            => null,
        'Imagem'            => null,
    ];

    // Método responsável por executar a formatação do campo data de nascimento
    // Antes de inserir no banco de dados, mantendo assim o padrão "Y-m-d"
    /*public function setDtNascimento(string $dateString)
    {
        $date = \DateTime::createFromFormat('d/m/Y', $dateString);
        $this->attributes['dt_nascimento'] = $date->format('Y-m-d');
        return $this;
    }

    // Método responsável por formatar a data no padrão "d/m/Y" antes de retornar os dados
    public function getDtNascimento(string $format = 'd/m/Y')
    {
        if(is_null($this->attributes['dt_nascimento'])) {
            return null;
        }

        $this->attributes['dt_nascimento'] = date($format, strtotime($this->attributes['dt_nascimento']));

        return $this->attributes['dt_nascimento'];
    }*/
}
