<?php

namespace App\Models;

use CodeIgniter\Model;

class PagamentoModel extends Model
{
    // definimos a tabela correspondente ao model
    protected $table          = 'pagamento';
    // definimos qual coluna na tabela `usuarios`corresponde à chave primária
    protected $primaryKey     = 'idPagamento';

    protected $returnType     = 'App\Entities\Pagamento';

    //protected $useSoftDeletes = true;
    protected $allowedFields  = ['desconto', 'idTipoPagamento'];
    /*protected $useTimestamps  = true;
    protected $createdField   = 'criado_em';
    protected $updatedField   = 'atualizado_em';
    protected $deletedField   = 'removido_em';*/

    // definimos as regras de validação
    protected $validationRules    = [
        'desconto'             => 'required|min_length[1]',

    ];

    // definimos as mensagens de validação
    protected $validationMessages = [
        'desconto' => [
            'required'   => 'Campo de preenchimento obrigatório.',
            'min_length' => 'O campo precisa ter no mínimo 1 caractéres.'
        ]
    ];

}