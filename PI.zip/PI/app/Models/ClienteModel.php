<?php

namespace App\Models;

use CodeIgniter\Model;

class ClienteModel extends Model
{
    // definimos a tabela correspondente ao model
    protected $table          = 'cliente';
    // definimos qual coluna na tabela `usuarios`corresponde à chave primária
    protected $primaryKey     = 'idCliente';

    protected $returnType     = 'App\Entities\Cliente';

    //protected $useSoftDeletes = true;
    protected $allowedFields  = ['nome', 'cpf', 'endereco', 'data_nasc', 'telefone', 'email', 'idUsuario', 'password', 'username'];
    //protected $useTimestamps  = true;
    /*protected $createdField   = 'criado_em';
    protected $updatedField   = 'atualizado_em';
    protected $deletedField   = 'removido_em';*/

    // definimos as regras de validação
    protected $validationRules    = [
        'nome'             => 'required|max_length[50]',
        'cpf'        => 'required|min_length[11]|max_length[11]',
        'endereco'         => 'required|min_length[10]',
        'data_nasc'    => 'required',
        'telefone' => 'required|integer|min_length[11]|max_length[13]',
        'email'            => 'required|valid_email|is_unique[cliente.email]'
    ];

    // definimos as mensagens de validação
    protected $validationMessages = [
        'nome' => [
            'required'   => 'Campo de preenchimento obrigatório.',
            'max_length' => 'O campo precisa ter no máximo 50 caractéres.'
        ],
        'cpf' => [
            'required'   => 'Campo de preenchimento obrigatório.',
            'min_length' => 'O campo precisa ter pelo menos 11 caracteres.'
        ],
        'endereco' => [
            'min_length'          => 'O campo precisa ter pelo menos 10 caracteres.'

        ],
        'data_nasc' => [
            'required'   => 'Campo de preenchimento obrigatório.',
            'valid_date' => 'Informe uma data válida.'
        ],
        'telefone' => [
            'min_length' => 'O campo precisa ter pelo menos 11 caracteres.',
            'max_length' => 'O campo precisa ter no máximo 13 caractéres.'
        ],
        'email' => [
            'required'    => 'Campo de preenchimento obrigatório.',
            'valid_email' => 'Informe um email válido.',
            'is_unique'   => 'Este email já está sendo utilizado por outro usuário.'
        ]
    ];

}