<?php

namespace App\Models;

use CodeIgniter\Model;

class CarinhoModel extends Model
{
    // definimos a tabela correspondente ao model
    protected $table          = 'carrinhos';
    // definimos qual coluna na tabela `usuarios`corresponde à chave primária
    protected $primaryKey     = 'id';

    protected $returnType     = 'App\Entities\Carrinho';

    protected $useSoftDeletes = true;
    protected $allowedFields  = ['quantidade'];
    protected $useTimestamps  = true;


    // definimos as regras de validação
    protected $validationRules    = [
        'quantidade'             => 'required|min_length[1]',
    ];

    // definimos as mensagens de validação
    protected $validationMessages = [
        'quantidade' => [
            'required'   => 'Campo de preenchimento obrigatório.',
            'min_length' => 'O campo precisa ter no mínimo 1 caractéres.'
        ]
    ];

}