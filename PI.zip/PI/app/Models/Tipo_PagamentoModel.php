<?php

namespace App\Models;

use CodeIgniter\Model;

class Tipo_PagamentoModel extends Model
{
    // definimos a tabela correspondente ao model
    protected $table          = 'tipo_pagamento';
    // definimos qual coluna na tabela `usuarios`corresponde à chave primária
    protected $primaryKey     = 'idTipoPagamento';

    protected $returnType     = 'App\Entities\Tipo_Pagamento';

    //protected $useSoftDeletes = true;
    protected $allowedFields  = ['descricao'];
   // protected $useTimestamps  = true;
   // protected $createdField   = 'criado_em';
    //protected $updatedField   = 'atualizado_em';
    //protected $deletedField   = 'removido_em';

    // definimos as regras de validação
    protected $validationRules    = [
        'descricao'             => 'required|max_length[50]',
    ];

    // definimos as mensagens de validação
    protected $validationMessages = [
        'descricao' => [
            'required'   => 'Campo de preenchimento obrigatório.',
            'max_length' => 'O campo precisa ter no máximo 50 caractéres.'
        ]
    ];

}