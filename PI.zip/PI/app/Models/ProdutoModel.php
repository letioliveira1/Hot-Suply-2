<?php

namespace App\Models;

use CodeIgniter\Model;

class ProdutoModel extends Model
{
    // definimos a tabela correspondente ao model
    protected $table          = 'produto';
    // definimos qual coluna na tabela `usuarios`corresponde à chave primária
    protected $primaryKey     = 'idProduto';

    protected $returnType     = 'App\Entities\Produto';

   // protected $useSoftDeletes = true;
    protected $allowedFields  = ['preco', 'descricao', 'Imagem' , 'idCategoria'];
    //protected $useTimestamps  = true;

    // definimos as regras de validação
    protected $validationRules    = [
        'preco'             => 'required|min_length[2]',
        'descricao'        => 'required|max_length[100]',
        'idCategoria'         => 'required|min_length[1]',
    ];

    // definimos as mensagens de validação
    protected $validationMessages = [
        'preco' => [
            'required'   => 'Campo de preenchimento obrigatório.',
            'min_length' => 'O campo precisa ter pelo menos 2 caracteres.'
        ],
        'descricao' => [
            'required'   => 'Campo de preenchimento obrigatório.',
            'max_length' => 'O campo precisa ter pelo menos 100 caracteres.'
        ],
        'idCategoria' => [
            'required'            => 'Campo de preenchimento obrigatório.',
            'min_length' => 'O campo precisa ter pelo menos 1 caracteres.'
        ]
    ];

}