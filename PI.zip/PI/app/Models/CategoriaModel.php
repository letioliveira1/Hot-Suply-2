<?php

namespace App\Models;

use CodeIgniter\Model;

class CategoriaModel extends Model
{
    // definimos a tabela correspondente ao model
    protected $table          = 'categoria';
    // definimos qual coluna na tabela `usuarios`corresponde à chave primária
    protected $primaryKey     = 'idCategoria';

    protected $returnType     = 'App\Entities\Categoria';

    //protected $useSoftDeletes = true;
    protected $allowedFields  = ['descricao'];
    //protected $useTimestamps  = true;


    // definimos as regras de validação
    protected $validationRules    = [
        'descricao'             => 'required|max_length[100]',
    ];

    // definimos as mensagens de validação
    //protected $validationMessages = [
      //  'nome' => [
        //    'max_length' => 'O campo precisa ter no máximo 100 caractéres.'
        //]
    //];

}


