<?php

namespace App\Models;

use CodeIgniter\Model;

class UsuarioModel extends Model
{
    // definimos a tabela correspondente ao model
    protected $table          = 'usuario';
    // definimos qual coluna na tabela `usuarios`corresponde à chave primária
    protected $primaryKey     = 'idUsuario';

    protected $returnType     = 'App\Entities\Usuario';

    //protected $useSoftDeletes = true;
    protected $allowedFields  = ['tipo_usuario'];
    //protected $useTimestamps  = true;
    /*protected $createdField   = 'criado_em';
    protected $updatedField   = 'atualizado_em';
    protected $deletedField   = 'removido_em';*/

    // definimos as regras de validação
    protected $validationRules    = [
        'tipo_usuario'             => 'required|max_length[50]'
        ];

    // definimos as mensagens de validação
    protected $validationMessages = [
        'tipo_usuario' => [
            'required'   => 'Campo de preenchimento obrigatório.',
            'max_length' => 'Deve se identificar se é usuario ou administrador.'
        ]
    ];

}