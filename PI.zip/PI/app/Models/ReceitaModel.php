<?php

namespace App\Models;

use CodeIgniter\Model;

class ReceitaModel extends Model
{
    // definimos a tabela correspondente ao model
    protected $table          = 'receita';
    // definimos qual coluna na tabela `usuarios`corresponde à chave primária
    protected $primaryKey     = 'idReceita';

    protected $returnType     = 'App\Entities\Receita';

    //protected $useSoftDeletes = true;
    protected $allowedFields  = ['nome','descricao', 'Imagem'];
    //protected $useTimestamps  = true;
    /*protected $createdField   = 'criado_em';
    protected $updatedField   = 'atualizado_em';
    protected $deletedField   = 'removido_em';*/

    // definimos as regras de validação
    protected $validationRules    = [
        'nome'             => 'required|min_length[1]',
        'descricao'             => 'required|min_length[1]',
        ];

    // definimos as mensagens de validação
    protected $validationMessages = [
        'nome' => [
            'required'   => 'Campo de preenchimento obrigatório.',
            'min_length' => 'Deve ter pelo menos 1 caracter.'
        ],

        'descricao' => [
            'required'   => 'Campo de preenchimento obrigatório.',
            'min_length' => 'Deve ter pelo menos 1 caracter.'
        ]
    ];

}