<?php

namespace App\Models;

use CodeIgniter\Model;

class PedidoModel extends Model
{
    // definimos a tabela correspondente ao model
    protected $table          = 'pedido';
    // definimos qual coluna na tabela `usuarios`corresponde à chave primária
    protected $primaryKey     = 'idPedido';

    protected $returnType     = 'App\Entities\Pedido';

   // protected $useSoftDeletes = true;
    protected $allowedFields  = ['quantidade', 'idProduto', 'idPagamento'];
   // protected $useTimestamps  = true;
 //   protected $createdField   = 'criado_em';
 //   protected $updatedField   = 'atualizado_em';
 //   protected $deletedField   = 'removido_em';

    // definimos as regras de validação
    protected $validationRules    = [
        'quantidade'             => 'required|min_length[1]',

    ];

    // definimos as mensagens de validação
    protected $validationMessages = [
        'quantidade' => [
            'required'   => 'Campo de preenchimento obrigatório.',
            'max_length' => 'O campo precisa ter no máximo 1 caractéres.'
        ]
    ];

}