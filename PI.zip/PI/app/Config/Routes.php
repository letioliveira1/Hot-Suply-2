<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Produto::indexSite');
$routes->get('/catalogo', 'Produto::indexPublico');
$routes->get('/receitas', 'receita::indexPublico');

//$routes->get('/login', 'Login::index');
//$routes->post('/login', 'Login::login');
//$routes->get('/logout', 'Login::logout');

$routes->get('/Usuario', 'Usuario::index');
$routes->get('/Usuario/novo', 'Usuario::novo');
$routes->post('/Usuario/novo', 'Usuario::novo');
$routes->get('/Usuario/editar/(:num)', 'Usuario::editar/$1');
$routes->post('/Usuario/editar/(:num)', 'Usuario::editar/$1');
$routes->get('/Usuario/excluir/(:num)', 'Usuario::excluir/$1');

$routes->get('/Carrinho', 'Carrinho::index');
$routes->get('/Carrinho/novo', 'Carrinho::novo');
$routes->post('/Carrinho/novo', 'Carrinho::novo');
$routes->get('/Carrinho/editar/(:num)', 'Carrinho::editar/$1');
$routes->post('/Carrinho/editar/(:num)', 'Carrinho::editar/$1');
$routes->get('/Carrinho/excluir/(:num)', 'Carrinho::excluir/$1');

$routes->get('/categoria', 'Categoria::index');
$routes->get('/categoria/novo', 'Categoria::novo');
$routes->post('/categoria/novo', 'Categoria::novo');
$routes->get('/categoria/editar/(:num)', 'Categoria::editar/$1');
$routes->post('/categoria/editar/(:num)', 'Categoria::editar/$1');
$routes->get('/categoria/excluir/(:num)', 'Categoria::excluir/$1');

$routes->get('/cliente', 'Cliente::index');
$routes->get('/cliente/novo', 'Cliente::novo');
$routes->post('/cliente/novo', 'Cliente::novo');
$routes->get('/cliente/editar/(:num)', 'Cliente::editar/$1');
$routes->post('/cliente/editar/(:num)', 'Cliente::editar/$1');
$routes->get('/cliente/excluir/(:num)', 'Cliente::excluir/$1');
$routes->get('/cliente/login', 'Cliente::login');
$routes->post('/cliente/login', 'Cliente::login');
$routes->get('/cliente/logout/', 'Cliente::logout');

$routes->get('/pagamento', 'Pagamento::index');
$routes->get('/pagamento/novo', 'Pagamento::novo');
$routes->post('/pagamento/novo', 'Pagamento::novo');
$routes->get('/pagamento/editar/(:num)', 'Pagamento::editar/$1');
$routes->post('/pagamento/editar/(:num)', 'Pagamento::editar/$1');
$routes->get('/pagamento/excluir/(:num)', 'Pagamento::excluir/$1');

$routes->get('/pedido', 'Pedido::index');
$routes->get('/Pedido/novo', 'Pedido::novo');
$routes->post('/Pedido/novo', 'Pedido::novo');
$routes->get('/Pedido/editar/(:num)', 'Pedido::editar/$1');
$routes->post('/Pedido/editar/(:num)', 'Pedido::editar/$1');
$routes->get('/Pedido/excluir/(:num)', 'Pedido::excluir/$1');

$routes->get('/produto', 'Produto::index');
$routes->get('/Produto/novo', 'Produto::novo');
$routes->post('/Produto/novo', 'Produto::novo');
$routes->get('/Produto/editar/(:num)', 'Produto::editar/$1');
$routes->post('/Produto/editar/(:num)', 'Produto::editar/$1');
$routes->get('/Produto/excluir/(:num)', 'Produto::excluir/$1');

$routes->get('/Tipo_Pagamento', 'Tipo_Pagamento::index');
$routes->get('/Tipo_Pagamento/novo', 'Tipo_Pagamento::novo');
$routes->post('/Tipo_Pagamento/novo', 'Tipo_Pagamento::novo');
$routes->get('/Tipo_Pagamento/editar/(:num)', 'Tipo_Pagamento::editar/$1');
$routes->post('/Tipo_Pagamento/editar/(:num)', 'Tipo_Pagamento::editar/$1');
$routes->get('/Tipo_Pagamento/excluir/(:num)', 'Tipo_Pagamento::excluir/$1');

$routes->get('/receita', 'receita::index');
$routes->get('/receita/novo', 'receita::novo');
$routes->post('/receita/novo', 'receita::novo');
$routes->get('/receita/editar/(:num)', 'receita::editar/$1');
$routes->post('/receita/editar/(:num)', 'receita::editar/$1');
$routes->get('/receita/excluir/(:num)', 'receita::excluir/$1');


//$routes->get('/produto', 'Produto::index');

