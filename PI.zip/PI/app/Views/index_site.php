<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hot Suply</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href=<?= base_url('css/index.css') ?>>

</head>
<body>

    <header>
        <div class="container">
            <div class="header-content">
                <h1>Hot Suply</h1>
                <div class="search-login">
                    <input type="text" placeholder="Pesquisar...">
                    <button><i class="fas fa-search"></i></button>
                    <button><i class="fas fa-user"></i><a href="<?= base_url('/cliente') ?>">Login</a></button>
                    <button><a href="<?= base_url('/Carrinho')?>">Carrinho</a></button>
                </div>
            </div>
        </div>
    </header>

<nav>
    <a href="<?= base_url('/') ?>">Início</a>
    <a href="<?= base_url('/catalogo') ?>">Catálogo</a>
    <a href="<?= base_url('/receitas') ?>">Receitas</a>

</nav>

<section id="inicio">
    <div class="container">
        <h2>Bem-vindo ao nosso site de Suplementos!</h2>
        <p>Encontre os melhores produtos para alcançar seus objetivos de saúde e fitness.</p>
    </div>
</section>

<section id="produtos">
    <div class="container">
        <h2>Nossos Produtos</h2>
        <p>Aqui estão alguns dos nossos produtos em destaque:</p>
        <?php 
        
        //print_r($produtos);
        
        foreach ($produtos as $produto) : ?>
        <main role="main">
      <div class="album py-5 bg-light">
        <div class="container">
          <div class="row">
            <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
                <img class="card-img-top"  src="<?= base_url('img/'.$produto->Imagem) . $produto->img ?>"  alt="Card image cap">
                <div class="card-body">
                <h4> <?= $produto->descricao ?> </h4>
                  <p class="card-text"> <?= $produto->preco ?> reais </p>
                  <div class="d-flex justify-content-between align-items-center">
                  </div>
                </div>
              </div>
            </div>
          </div> 
        </div>
      </div>
      <?php endforeach; ?> 
    </div>
</section>

<section id="sobre">
    <div class="container">
        <h2>Sobre Nós</h2>
        <p>Somos uma loja comprometida em fornecer os melhores suplementos para atletas e entusiastas do fitness.</p>
    </div>
</section>

<section id="contato" class="contato">
    <div class="container">
        <h2>Entre em Contato</h2>
        <p>Estamos aqui para ajudar! Entre em contato conosco:</p>
        <p>Email: contato@hotsuply.com</p>
        <p>Telefone: (54) 3242-5148</p>
    </div>
</section>

<footer>
    <div class="container">
        <p>&copy; 2024 HOT SUPLY. Todos os direitos reservados.</p>
    </div>
</footer>

</body>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</html>
