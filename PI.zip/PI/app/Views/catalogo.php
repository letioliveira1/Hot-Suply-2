<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title>Exemplo de álbum Bootstrap</title>

    <!-- Principal CSS do Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"  crossorigin="anonymous">

    <!-- Estilos customizados para este template -->
    <link rel="stylesheet" href=<?= base_url('css/catalogo.css') ?>>

    <header>
      <div class="container">
          <div class="header-content">
              <h1>Hot Suply</h1>
              <div class="search-login">
                  <input type="text" placeholder="Pesquisar...">
                  <button><i class="fas fa-search"></i></button>
                  <button><i class="fas fa-user"></i><a href="login.html">Login</a></button>
              </div>
          </div>
      </div>
  </header>
  </head>

  <nav>
    <a href="<?= base_url('/') ?>">Inicio</a>
    <a href="<?= base_url('/catalogo') ?>">Catálogo</a>
    <a href="<?= base_url('/receitas') ?>">Receitas</a>

  </nav>

  <body>

    <section>
      <div class="collapse bg-dark" id="navbarHeader">
        <div class="container">
          <div class="row">
            <div class="col-sm-8 col-md-7 py-4">
              <h4 class="text-white">Sobre</h4>
              <p class="text-muted">Adicione alguma informação sobre o álbum abaixo (autor ou qualquer outro background). Faça essas informações terem algumas frases, para a galera ter algumas informações que besliscar. Além disso, use link nelas para as redes sociais ou informações de contato.</p>
            </div>
            <div class="col-sm-4 offset-md-1 py-4">
              <h4 class="text-white">Contato</h4>
              <ul class="list-unstyled">
                <li><a href="#" class="text-white">Me siga no Twitter</a></li>
                <li><a href="#" class="text-white">Curta no Facebook</a></li>
                <li><a href="#" class="text-white">Me envie um e-mail</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>

    <main role="main">

        <?php 
        
        //print_r($produtos);
        
        foreach ($produtos as $produto) : ?>
        <main role="main">
   
            

      <div class="album py-5 bg-light">
        <div class="container">
          <div class="row">
            <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
                <img class="card-img-top"  src="<?= base_url('img/'.$produto->Imagem) . $produto->img ?>"  alt="Card image cap">
                <div class="card-body">
                <h4> <?= $produto->descricao ?> </h4>
                  <p class="card-text"> <?= $produto->preco ?> reais </p>
                  <div class="d-flex justify-content-between align-items-center">
                  </div>
                </div>
              </div>
            </div>
          </div> 
        </div>
      </div>
      <?php endforeach; ?> 

    </main>
    

    <footer class="text-muted">
      <div class="container">
        <p>&copy; 2024 HOT SUPLY. Todos os direitos reservados.</p>
      </div>
    </footer>

    <!-- Principal JavaScript do Bootstrap
    ================================================== -->
    <!-- Foi colocado no final para a página carregar mais rápido -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="../../assets/js/vendor/popper.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>
    <script src="../../assets/js/vendor/holder.min.js"></script>
  </body>
</html>
