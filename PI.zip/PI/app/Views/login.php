<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
  <link rel="stylesheet" href=<?= base_url('css/login.css') ?>>
</head>


<body>
 <h2>Login</h2>

 <?php if(session()->getFlashdata('error')): ?>
 <div><?= session()->getFlashdata('error') ?></div>
 <?php endif; ?>

 <form method="post" action="<?= base_url('/cliente/login') ?>">
    <label>Username:</label>
 <input type="text" name="username" required><br>
    <label>Password:</label>
 <input type="password" name="password" required><br>
 <button type="submit">Login</button>
 </form>

 <div class="cadastro">
   <p>Cadastre-se</p>
   <button class="boto"><a href="<?= base_url('cliente/novo') ?>">Cadastrar</a></button>
 </div>
</body>
</html>
