begin;

CREATE DATABASE hs;

Use hs;

CREATE TABLE usuario
(
    idUsuario int(5) NOT NULL AUTO_INCREMENT,
    tipo_usuario varchar(50) NOT NULL,
    PRIMARY KEY(idUsuario)
);
CREATE TABLE cliente
(
    idCliente int(5) NOT NULL AUTO_INCREMENT,
    nome varchar(100) NOT NULL,
    cpf varchar(11) NOT NULL,
    endereco varchar (200) NOT NULL,
    data_nasc varchar (10) NOT NULL,
    telefone varchar (15) NOT NULL,
    email varchar(100) NOT NULL,
    idUsuario int(5) NOT NULL,
    PRIMARY KEY(idCliente),
    FOREIGN KEY (idUsuario) REFERENCES usuario(idUsuario)
);

CREATE TABLE categoria
(
    idCategoria int(5) NOT NULL AUTO_INCREMENT,
    descricao varchar(100) NOT NULL,
    PRIMARY KEY(idCategoria)
);


CREATE TABLE produto
(
    idProduto int(5) NOT NULL AUTO_INCREMENT,
    preco varchar(100) NOT NULL,
    descricao varchar(100) NOT NULL,
    idCategoria int(5) NOT NULL,
    PRIMARY KEY(idProduto),
    FOREIGN KEY (idCategoria) REFERENCES categoria(idCategoria)

);

CREATE TABLE carrinho
(
    idCarrinho int(5) NOT NULL AUTO_INCREMENT,
    quantidade varchar(100) NOT NULL,
    idCliente int(5) NOT NULL,
    idProduto int(5) NOT NULL,
    PRIMARY KEY(idCarrinho),
    FOREIGN KEY (idCliente) REFERENCES cliente(idCliente),
    FOREIGN KEY (idProduto) REFERENCES produto(idProduto)
);

CREATE TABLE tipo_pagamento
(
    idTipoPagamento int(5) NOT NULL AUTO_INCREMENT,
    descricao varchar(100) NOT NULL,
    PRIMARY KEY(idTipoPagamento)
);

CREATE TABLE pagamento
(
    idPagamento int(5) NOT NULL AUTO_INCREMENT,
    desconto varchar(100) NOT NULL,
    idTipoPagamento int(5) NOT NULL,
    PRIMARY KEY(idPagamento),
    FOREIGN KEY (idTipoPagamento) REFERENCES tipo_pagamento(idTipoPagamento)
);

CREATE TABLE pedido
(
    idPedido int(5) NOT NULL AUTO_INCREMENT,
    quantidade varchar(100) NOT NULL,
    idPagamento int(5) NOT NULL,
    idProduto int(5) NOT NULL,
    PRIMARY KEY(idPedido),
    FOREIGN KEY (idProduto) REFERENCES produto(idProduto),
    FOREIGN KEY (idPagamento) REFERENCES pagamento(idPagamento)
);

commit;
